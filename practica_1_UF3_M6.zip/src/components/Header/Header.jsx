export function header() {
  return  (
  <div className="header-wrapper"><h1> <span className="blue-span">Soft</span><span className="white-span">GPL</span> </h1></div>
  );
 
}

export default header;
