export function Footer() {
    return (
      <div className="footer">
        <nav>
          <ul>
              <li>HOSTING CONFIABLE</li>
              <li>CREAR WEB</li>
              <li>RECURSOS</li>
              <li>APRENDE</li>
              <li>NOSALTRES</li>
          </ul>
        </nav>
      </div>
    );
  }
  
  export default Footer;
  